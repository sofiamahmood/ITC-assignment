const express = require('express');
const router = express.Router();

// declare axios for making http requests
const axios = require('axios');
// Mocking checkin data
//const API = 'https://api.myjson.com/bins/1gbtq3';
const API = 'http://localhost:3000/posts.json';


/* GET api listing. */
router.get('/', (req, res) => {
  res.send('api works');
});


router.get('/posts',function(req,res){
	let bookingCode = req.query.bookingCode;
	let familyName = req.query.familyName;
   axios.get(`${API}`)
    .then(posts => {	
		var pData = posts.data;
		var bookingCodeValidFlag = false;
		var familyNameValidFlag = false;
		var checkinAvailabilityFlag = false;
		for(var i=0; i < pData.length; i++){
			if(pData[i].bookingCode == bookingCode){
				bookingCodeValidFlag = true;
			}
			if(pData[i].familyName == familyName){
				familyNameValidFlag = true;
			}
			if(pData[i].checkinAvailability == 'available'){
				checkinAvailabilityFlag = true;
			}
			
		}
		if(bookingCodeValidFlag && familyNameValidFlag && checkinAvailabilityFlag){
			console.log('success');
			res.status(200).json(posts.data);
		}else if(!bookingCodeValidFlag){
			res.status(9001).json('invalid Booking code');
		}else if(!familyNameValidFlag){
			res.status(9002).json('invalid family name');
		}
		else if(!checkinAvailabilityFlag){
			res.status(9003).json('checkin not available');
		}
    })
    .catch(error => {
      res.status(500).send(error)
    });
});



module.exports = router;