import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import {FormControl, FormGroupDirective, NgForm, Validators} from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import { Headers, Http,HttpModule, Response } from "@angular/http";
import { HttpClientModule, HttpClient} from '@angular/common/http';
 import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable'; 
import { PostCheckinService } from "./post-checkin-service"

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent{	
	posts: any = [];
	bookingSuccessful: boolean = false;
	validation_errors: Array<any> = [];
    constructor(private translate: TranslateService, private postCheckinService: PostCheckinService) {
        translate.addLangs(["en", "nl"]);
        translate.setDefaultLang('en');
        let browserLang = translate.getBrowserLang();
        translate.use(browserLang.match(/en|nl/) ? browserLang : 'en');
		
    }
	bookingCodeFormControl = new FormControl('', [
		Validators.required,
		Validators.pattern('[a-zA-Z0-9]+'),
	  ]);
	
	 familyNameFormControl = new FormControl('', [
		Validators.required,
		Validators.pattern('[a-zA-Z]+'),
	  ]);
	   checkinFormSubmit(event) {
		let bookingCodeVal = this.bookingCodeFormControl.value;
		let familyNameVal = this.familyNameFormControl.value;
		this.postCheckinService.validateCheckinForm(bookingCodeVal, familyNameVal).subscribe(posts => {
		  this.posts = posts;
		  if(this.posts.status == 200){
			this.bookingSuccessful = true;
		  }else{
			this.bookingSuccessful = false;
		  }
		},
          err => {
            // Something went wrong, let's collect all errors in a class attribute
			  if(err.body){
				let errors = err.json().errors;
				  for(var i = 0; i < errors.length; i++) {
					this.validation_errors.push(errors[i])
				  }
			  }else{
				this.validation_errors.push('Internal Error');
			  }
			  console.log(this.validation_errors);
         });
	  }
	

	  matcher = new MyErrorStateMatcher();
}
